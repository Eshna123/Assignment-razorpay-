package io.github.turskyi.tasklist.presentation.interfaces

interface ItemClickListener {
    fun onItemClickListener(itemId: Int)
}